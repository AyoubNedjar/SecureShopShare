<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="header-title"><?php echo e(__('My Articles')); ?></h2>
     <?php $__env->endSlot(); ?>

    <link rel="stylesheet" href="<?php echo e(asset('articleCss/index.css')); ?>">

    <div class="container">
        <div class="content-wrapper">
            <!-- Success message -->
            <?php if(session('success')): ?>
                <div class="status-message success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <a href="<?php echo e(route('articles.create')); ?>" class="btn btn-primary"><?php echo e(__('Create New Article')); ?></a>

            <?php if($articles->isEmpty()): ?>
                <p><?php echo e(__("You don't have any articles yet. Create your first article!")); ?></p>
            <?php else: ?>
                <ul class="articles-list">
                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="article-item">
                            <a href="<?php echo e(route('articles.show', $article->id)); ?>"><?php echo e($article->title); ?></a>
                            <p class="boutique-info">
                                <strong><?php echo e(__('Shop:')); ?></strong> <?php echo e($article->boutique->name); ?>

                            </p>
                            <div class="actions">
                                <a href="<?php echo e(route('articles.edit', $article->id)); ?>" class="btn btn-secondary"><?php echo e(__('Edit')); ?></a>
                                <form action="<?php echo e(route('articles.destroy', $article->id)); ?>" method="POST" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger"><?php echo e(__('Delete')); ?></button>
                                </form>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Y\Desktop\secg4_secondesess\secureWeb-Shop\resources\views/articles/index.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="header-content">
            <a href="<?php echo e(route('dashboard')); ?>" class="header-link">
                <h2 class="header-title"><?php echo e(__('Dashboard')); ?></h2>
            </a>
            <div class="menu-icon" id="menu-icon">
                <div class="bar"></div>
                <div class="bar"></div>
                <div class="bar"></div>
            </div>
            <div class="dropdown-menu hidden" id="dropdown-menu">
                <a href="<?php echo e(route('profile.edit')); ?>" class="dropdown-item"><?php echo e(__('Profile')); ?></a>
                <form method="POST" action="<?php echo e(route('logout')); ?>" class="dropdown-item">
                    <?php echo csrf_field(); ?>
                    <button type="submit"><?php echo e(__('Logout')); ?></button>
                </form>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0/dist/fancybox/fancybox.css"/>

    <!-- Become a Moderator Section (Visible only for non-moderators) -->
    <?php if(!auth()->user()->isModerator()): ?>
    <div class="section become-moderator-section">
        <h3 class="section-title"><?php echo e(__('Devenir modérateur')); ?></h3>
        
        <form action="<?php echo e(route('user.showPromotionForm')); ?>" method="GET" style="display:inline;">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-secondary"><?php echo e(__('Devenir modérateur')); ?></button>
        </form>
    </div>
    <?php endif; ?>

    <div class="dashboard-container">
        <div class="content-wrapper">
            <!-- Success message with pop-up -->
            <?php if(session('success')): ?>
                <div class="status-message success" id="status-message">
                    <div class="status-text"><?php echo e(session('success')); ?></div>
                </div>
            <?php endif; ?>

            <!-- Welcome message that will be shown as a pop-up -->
            <?php if(session('welcomeMessage')): ?>
                <div class="status-message" id="status-message">
                    <div class="status-text"><?php echo e(__("You're logged in!")); ?></div>
                </div>
                <?php session()->forget('welcomeMessage'); ?>
            <?php endif; ?>

            <!-- Boutiques Section -->
            <div class="section boutiques-section">
                <h3 class="section-title"><?php echo e(__('My Shops')); ?></h3>
                <a href="<?php echo e(route('boutiques.create')); ?>" class="btn btn-primary"><?php echo e(__('Create New Shop')); ?></a>
                <?php if($boutiques->isEmpty()): ?>
                    <p class="no-items-message"><?php echo e(__("You don't have any shops yet. Create your first shop!")); ?></p>
                <?php else: ?>
                    <ul class="list boutiques-list">
                        <?php $__currentLoopData = $boutiques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boutique): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-item boutique-item">
                                <a href="<?php echo e(route('boutiques.show', $boutique->id)); ?>" class="item-link"><?php echo e($boutique->name); ?></a>
                                <div class="actions">
                                    <a href="<?php echo e(route('boutiques.edit', $boutique->id)); ?>" class="btn btn-secondary"><?php echo e(__('Edit')); ?></a>
                                    <form action="<?php echo e(route('boutiques.destroy', $boutique->id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger"><?php echo e(__('Delete')); ?></button>
                                    </form>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>

            <!-- Articles Section -->
            <div class="section articles-section">
                <h3 class="section-title"><?php echo e(__('My Articles')); ?></h3>
                <a href="<?php echo e(route('articles.create')); ?>" class="btn btn-primary spacing-bottom"><?php echo e(__('Add New Article')); ?></a>
                
                <?php if($articles->isEmpty()): ?>
                    <p class="no-items-message"><?php echo e(__("You don't have any articles yet. Add your first article!")); ?></p>
                <?php else: ?>
                    <ul class="list articles-list">
                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-item article-item">
                                <a href="<?php echo e(route('articles.show', $article->id)); ?>" class="item-link"><?php echo e($article->title); ?></a>
                                <div class="actions">
                                    <a href="<?php echo e(route('articles.edit', $article->id)); ?>" class="btn btn-secondary"><?php echo e(__('Edit')); ?></a>
                                    <form action="<?php echo e(route('articles.destroy', $article->id)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger"><?php echo e(__('Delete')); ?></button>
                                    </form>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>

            <!-- Publicly Shared Boutiques Section -->
            <div class="section public-boutiques-section">
                <h3 class="section-title"><?php echo e(__('Publicly Shared Shops')); ?></h3>
                <?php if($publicBoutiques->isEmpty()): ?>
                    <p class="no-items-message"><?php echo e(__('No publicly shared shops found.')); ?></p>
                <?php else: ?>
                    <ul class="list boutiques-list">
                        <?php $__currentLoopData = $publicBoutiques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boutique): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-item boutique-item">
                                <a href="<?php echo e(route('boutiques.show', $boutique->id)); ?>" class="item-link"><?php echo e($boutique->name); ?></a>
                                <p class="boutique-description"><?php echo e($boutique->description); ?></p>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>

            <!-- Boutiques Shared with User Section -->
            <div class="section shared-with-user-boutiques-section">
                <h3 class="section-title"><?php echo e(__('Shops Shared with You')); ?></h3>
                <?php if($sharedWithUserBoutiques->isEmpty()): ?>
                    <p class="no-items-message"><?php echo e(__('No shops shared with you found.')); ?></p>
                <?php else: ?>
                    <ul class="list boutiques-list">
                        <?php $__currentLoopData = $sharedWithUserBoutiques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boutique): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-item boutique-item">
                                <a href="<?php echo e(route('boutiques.show', $boutique->id)); ?>" class="item-link"><?php echo e($boutique->name); ?></a>
                                <p class="boutique-description"><?php echo e($boutique->description); ?></p>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>

            <!-- Publicly Shared Articles Section -->
            <div class="section public-articles-section">
                <h3 class="section-title"><?php echo e(__('Publicly Shared Articles')); ?></h3>
                <?php if($publicArticles->isEmpty()): ?>
                    <p class="no-items-message"><?php echo e(__('No publicly shared articles found.')); ?></p>
                <?php else: ?>
                    <ul class="list articles-list">
                        <?php $__currentLoopData = $publicArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-item article-item">
                                <a href="<?php echo e(route('articles.show', $article->id)); ?>" class="item-link"><?php echo e($article->title); ?></a>
                                <p class="article-description"><?php echo e($article->description); ?></p>
                                <p class="article-price"><?php echo e(__('Price')); ?>: $<?php echo e($article->price); ?></p>
                                <p class="article-boutique"><?php echo e(__('In shop')); ?>: <a href="<?php echo e(route('boutiques.show', $article->boutique->id)); ?>" class="item-link"><?php echo e($article->boutique->name); ?></a></p>
                                <p class="article-creator"><?php echo e(__('Created by')); ?>: <?php echo e($article->user->name); ?></p>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>

            <!-- Articles Shared with User Section -->
            <div class="section private-articles-section">
                <h3 class="section-title"><?php echo e(__('Articles Shared with You')); ?></h3>
                <?php if($privateArticles->isEmpty()): ?>
                    <p class="no-items-message"><?php echo e(__('No articles shared with you found.')); ?></p>
                <?php else: ?>
                    <ul class="list articles-list">
                        <?php $__currentLoopData = $privateArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-item article-item">
                                <a href="<?php echo e(route('articles.show', $article->id)); ?>" class="item-link"><?php echo e($article->title); ?></a>
                                <p class="article-description"><?php echo e($article->description); ?></p>
                                <p class="article-price"><?php echo e(__('Price')); ?>: $<?php echo e($article->price); ?></p>
                                <p class="article-boutique"><?php echo e(__('In shop')); ?>: <a href="<?php echo e(route('boutiques.show', $article->boutique->id)); ?>" class="item-link"><?php echo e($article->boutique->name); ?></a></p>
                                <p class="article-creator"><?php echo e(__('Created by')); ?>: <?php echo e($article->user->name); ?></p>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>

            <!-- Moderation Section (Visible only for moderators) -->
            <?php if(auth()->user()->isModerator()): ?>
            <div class="section moderation-section">
                <h3 class="section-title"><?php echo e(__('Moderation')); ?></h3>
                <a href="<?php echo e(route('moderations.index')); ?>" class="btn btn-warning"><?php echo e(__('Go to Moderation')); ?></a>
            </div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Y\Desktop\secg4_secondesess\secureWeb-Shop\resources\views/dashboard.blade.php ENDPATH**/ ?>
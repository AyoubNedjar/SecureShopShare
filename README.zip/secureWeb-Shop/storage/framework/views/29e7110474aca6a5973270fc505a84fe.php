<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Y\Desktop\secg4_secondesess\secureWeb-Shop\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>
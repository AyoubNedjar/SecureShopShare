<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="/css/home.css">
</head>
<body>
    <div class="container">
        <h1>Welcome to the Secure Shop</h1>
        <a href="/login" class="btn-login">Login</a>
        <a href="/register" class="btn-login">register</a>


    </div>
</body>
</html>
<?php /**PATH C:\Users\Y\Desktop\secg4_secondesess\secureWeb-Shop\resources\views/welcome.blade.php ENDPATH**/ ?>
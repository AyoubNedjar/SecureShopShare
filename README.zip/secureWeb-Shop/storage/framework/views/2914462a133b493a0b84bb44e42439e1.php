<?php echo e($slot); ?>

<?php /**PATH C:\Users\Y\Desktop\secg4_secondesess\secureWeb-Shop\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>
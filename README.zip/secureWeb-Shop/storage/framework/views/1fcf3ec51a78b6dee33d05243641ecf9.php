<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="header-title"><?php echo e($article->title); ?></h2>
     <?php $__env->endSlot(); ?>

    <link rel="stylesheet" href="<?php echo e(asset('articleCss/show.css')); ?>">

    <div class="container">
        <div class="content-wrapper">
            <div class="article-details">
                <h3 class="article-title"><?php echo e($article->title); ?></h3>
                <p class="article-description"><?php echo e($article->description); ?></p>
                <p class="article-price"><?php echo e(__('Price')); ?>: $<?php echo e($article->price); ?></p>
                <p class="article-boutique"><?php echo e(__('Shop')); ?>: <a href="<?php echo e(route('boutiques.show', $article->boutique->id)); ?>" class="item-link"><?php echo e($article->boutique->name); ?></a></p>
                <p class="article-creator"><?php echo e(__('Created by')); ?>: <?php echo e($article->user->name); ?></p>

                <!-- Affichage de l'image décryptée -->
                <?php if($imageUrl): ?>
                    <h4><?php echo e(__('Image')); ?></h4>
                    <img src="<?php echo e($imageUrl); ?>" alt="Article Image" style="max-width: 50%; height: auto;">
                <?php else: ?>
                    <p><?php echo e(__('No image available')); ?></p>
                <?php endif; ?>
            </div>

            <!-- Share Form -->
            <div class="share-section">
                <h4><?php echo e(__('Share This Article')); ?></h4>
                <form action="<?php echo e(route('articles.share', $article->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <label>
                        <input type="radio" name="share_type" value="public" checked>
                        <?php echo e(__('Share Publicly')); ?>

                    </label>
                    <label>
                        <input type="radio" name="share_type" value="private">
                        <?php echo e(__('Share with User')); ?>

                    </label>
                    
                    <div id="user-selection" style="display: none;">
                        <label for="shared_with_user_id"><?php echo e(__('Select User')); ?></label>
                        <select name="shared_with_user_id" id="shared_with_user_id">
                            <!-- Dynamically populate this dropdown with users -->
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-primary"><?php echo e(__('Share')); ?></button>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.querySelectorAll('input[name="share_type"]').forEach(input => {
            input.addEventListener('change', function() {
                document.getElementById('user-selection').style.display = this.value === 'private' ? 'block' : 'none';
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Y\Desktop\secg4_secondesess\secureWeb-Shop\resources\views/articles/show.blade.php ENDPATH**/ ?>
<!-- resources/views/boutiques/show.blade.php -->
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="header-title"><?php echo e($boutique->name); ?></h2>
     <?php $__env->endSlot(); ?>

    <link rel="stylesheet" href="<?php echo e(asset('boutiqueCss/show.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('boutiqueCss/share.css')); ?>">

    <div class="container">
        <div class="content-wrapper">
            <div class="boutique-details">
                <h3 class="boutique-name"><?php echo e($boutique->name); ?></h3>
                <p class="boutique-description"><?php echo e($boutique->description); ?></p>
                
                <h4 class="section-title"><?php echo e(__('Articles in this Shop')); ?></h4>
                <?php if($boutique->articles->isEmpty()): ?>
                    <p><?php echo e(__("No articles found in this shop.")); ?></p>
                <?php else: ?>
                    <ul class="article-list">
                        <?php $__currentLoopData = $boutique->articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="article-item">
                                <a href="<?php echo e(route('articles.show', $article->id)); ?>" class="item-link"><?php echo e($article->title); ?></a>
                                <?php if($article->share_type === 'public'): ?>
                                    <span><?php echo e(__('Shared publicly')); ?></span>
                                <?php elseif($article->shared_with_user_id): ?>
                                    <span><?php echo e(__('Shared with')); ?>: <?php echo e($article->sharedWithUser->name); ?></span>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>

            <!-- Share Form -->
            <div class="share-section">
                <h4><?php echo e(__('Share This Shop')); ?></h4>
                <form action="<?php echo e(route('boutiques.share', $boutique->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <label>
                        <input type="radio" name="share_type" value="public" <?php echo e($boutique->share_type === 'public' ? 'checked' : ''); ?>>
                        <?php echo e(__('Share Publicly')); ?>

                    </label>
                    <label>
                        <input type="radio" name="share_type" value="private" <?php echo e($boutique->share_type === 'private' ? 'checked' : ''); ?>>
                        <?php echo e(__('Share with User')); ?>

                    </label>
                    
                    <div id="user-selection" style="<?php echo e($boutique->share_type === 'private' ? 'display: block;' : 'display: none;'); ?>">
                        <label for="shared_with_user_id"><?php echo e(__('Select User')); ?></label>
                        <select name="shared_with_user_id" id="shared_with_user_id">
                            <!-- Dynamically populate this dropdown with users -->
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>" <?php echo e($boutique->shared_with_user_id == $user->id ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-primary"><?php echo e(__('Share')); ?></button>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.querySelectorAll('input[name="share_type"]').forEach(input => {
            input.addEventListener('change', function() {
                document.getElementById('user-selection').style.display = this.value === 'private' ? 'block' : 'none';
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Y\Desktop\secg4_secondesess\secureWeb-Shop\resources\views/boutiques/show.blade.php ENDPATH**/ ?>